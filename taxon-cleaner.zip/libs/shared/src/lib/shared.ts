// export function shared(): string {
//   return 'shared';
// }
