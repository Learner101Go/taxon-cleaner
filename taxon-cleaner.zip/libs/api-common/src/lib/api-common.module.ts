// import { Module } from '@nestjs/common';
// import { TaxonProcessorService } from './processing/taxon-processor.service';
// import { AuthorNormalizationService } from './processing/author-normalization.service';
// import { TaxonResolutionService } from './processing/taxon-resolution.service';
// import { CoordinateValidationService } from './processing/coordinate-validation.service';

// @Module({
//   controllers: [],
//   providers: [
//     TaxonProcessorService,
//     AuthorNormalizationService,
//     TaxonResolutionService,
//     CoordinateValidationService,
//   ],
//   exports: [],
// })
// export class ApiCommonModule {}
