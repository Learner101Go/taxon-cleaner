import { Redis } from 'ioredis';
import { ConfigService } from '../config/config.service';

export function createRedisConnection(url: string): Redis {
  return new Redis(url, {
    maxRetriesPerRequest: null,
    enableReadyCheck: false,
    connectTimeout: 10000,
  });
}
