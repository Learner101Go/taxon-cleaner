export interface AppError {
  code: string;
  message: any;
  timestamp: string;
}
