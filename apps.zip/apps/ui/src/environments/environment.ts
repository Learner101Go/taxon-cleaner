export const environment = {
  production: false,
  apiUrl: 'http://localhost:3001/api',
  s2Url: 'http://localhost:8080/api/v1',
};
