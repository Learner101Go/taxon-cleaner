import { Route, Routes } from '@angular/router';

export const appRoutes: Routes = [];
